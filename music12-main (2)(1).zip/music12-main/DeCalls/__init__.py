from .DeCalls import pytgcalls, run
